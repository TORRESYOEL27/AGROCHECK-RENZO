package com.agrocheck.app;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.widget.*;

public class SummaryActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        int green=Color.rgb(27,94,32);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(22,24,22,24); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(0xFFF5F5F0);
        ScrollView sc=new ScrollView(this); sc.addView(root); setContentView(sc);
        TextView title=new TextView(this); title.setText("Resumen de Alerta"); title.setTextSize(24); title.setTextColor(green); title.setTypeface(null,1); title.setGravity(Gravity.CENTER); root.addView(title);
        ImageView image=new ImageView(this); image.setBackgroundColor(0xFFE3E8D7); image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        String encoded=getIntent().getStringExtra("photo");
        if(encoded!=null && !encoded.isEmpty()) { byte[] bytes=Base64.decode(encoded,Base64.DEFAULT); image.setImageBitmap(BitmapFactory.decodeByteArray(bytes,0,bytes.length)); }
        else image.setImageResource(android.R.drawable.ic_menu_gallery);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,270); ip.setMargins(0,20,0,18); root.addView(image,ip);
        String pest=getIntent().getStringExtra("pest"), lat=getIntent().getStringExtra("lat"), lon=getIntent().getStringExtra("lon");
        TextView details=new TextView(this); details.setText("Plaga: "+pest+"\n\nLatitud: "+lat+"\nLongitud: "+lon); details.setTextSize(19); details.setTextColor(0xFF212121); details.setPadding(18,20,18,20); details.setBackgroundColor(0xFFE5EBD7); root.addView(details);
        Button confirm=new Button(this); confirm.setText("CONFIRMAR ENVÍO"); confirm.setTextColor(Color.WHITE); confirm.setTextSize(17); confirm.setAllCaps(false); confirm.setBackgroundColor(green); confirm.setMinHeight(60);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,22,0,0); root.addView(confirm,bp);
        confirm.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Alerta confirmada").setMessage("La alerta se ha preparado correctamente en este dispositivo. Para enviarla a un servidor se necesita conectar una API o base de datos.").setPositiveButton("ACEPTAR",(a,w)->finish()).show());
    }
}