package com.agrocheck.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int green = Color.rgb(27,94,32), yellow = Color.rgb(255,193,7), ink = Color.rgb(33,33,33);
    LinearLayout root;
    @Override public void onCreate(Bundle b) { super.onCreate(b); showLogin(); }

    GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(18);
        if (stroke != 0) d.setStroke(2, stroke); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); t.setGravity(Gravity.CENTER); return t;
    }
    EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(18); e.setHint(hint);
        e.setInputType(type); e.setPadding(18, 8, 18, 8); e.setBackground(shape(Color.WHITE, 0xFF9EAAA6));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 58); p.setMargins(0, 9, 0, 9); e.setLayoutParams(p); return e;
    }
    Button button(String label, int color, int textColor) {
        Button b = new Button(this); b.setText(label); b.setTextSize(17); b.setTextColor(textColor);
        b.setAllCaps(false); b.setTypeface(null, Typeface.BOLD); b.setBackground(shape(color, 0));
        b.setMinHeight(58); b.setElevation(2); return b;
    }
    void setup(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF5F5F0);
        ScrollView sc = new ScrollView(this); sc.addView(root); setContentView(sc);
        getWindow().setStatusBarColor(0xFF174D1B);
    }
    void showLogin() {
        setup("AgroCheck");
        TextView logo = text("🌱", 64, green, true); root.addView(logo);
        TextView name = text("AgroCheck", 34, green, true); root.addView(name);
        root.addView(text("Control de plagas en cultivos", 17, ink, false));
        View gap = new View(this); root.addView(gap, new LinearLayout.LayoutParams(1, 35));
        EditText dni = field("DNI", InputType.TYPE_CLASS_NUMBER);
        EditText pass = field("Contraseña", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(dni); root.addView(pass);
        Button enter = button("INGRESAR", green, Color.WHITE);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 62); bp.setMargins(0, 18, 0, 0); root.addView(enter, bp);
        enter.setOnClickListener(v -> {
            if (dni.getText().toString().trim().isEmpty() || pass.getText().toString().isEmpty()) {
                Toast.makeText(this, "Ingresa tu DNI y contraseña", Toast.LENGTH_SHORT).show(); return;
            }
            startActivity(new Intent(this, RegisterActivity.class));
        });
    }
}