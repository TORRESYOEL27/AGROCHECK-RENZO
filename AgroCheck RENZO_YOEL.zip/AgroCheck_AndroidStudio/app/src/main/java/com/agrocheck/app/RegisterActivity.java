package com.agrocheck.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.*;
import java.io.ByteArrayOutputStream;
import android.util.Base64;

public class RegisterActivity extends Activity {
    static final int CAMERA = 10, LOCATION = 11;
    ImageView photo; TextView coordinates; EditText pest; String lat="-7.163800", lon="-78.500300", photo64="";
    int green=Color.rgb(27,94,32), yellow=Color.rgb(255,193,7);
    @Override public void onCreate(Bundle b) { super.onCreate(b); build(); }
    TextView label(String s,int size) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xFF212121); t.setGravity(Gravity.CENTER); return t; }
    android.graphics.drawable.GradientDrawable bg(int c) { android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable(); d.setColor(c); d.setCornerRadius(16); return d; }
    Button btn(String s,int c,int tc) { Button b=new Button(this); b.setText(s); b.setTextColor(tc); b.setTextSize(16); b.setAllCaps(false); b.setBackground(bg(c)); b.setMinHeight(58); return b; }
    void build() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(20,20,20,20); root.setBackgroundColor(0xFFF5F5F0);
        ScrollView sc=new ScrollView(this); sc.addView(root); setContentView(sc);
        TextView title=label("Registrar Plaga",24); title.setTypeface(null,1); root.addView(title);
        photo=new ImageView(this); photo.setImageResource(android.R.drawable.ic_menu_gallery); photo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        photo.setBackground(bg(0xFFE3E8D7)); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,210); pp.setMargins(0,18,0,12); root.addView(photo,pp);
        Button camera=btn("TOMAR FOTO",green,Color.WHITE); root.addView(camera); camera.setOnClickListener(v->{ Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE); if(i.resolveActivity(getPackageManager())!=null) startActivityForResult(i,CAMERA); else Toast.makeText(this,"No se encontró una cámara",0).show(); });
        Button gps=btn("OBTENER UBICACIÓN",yellow,Color.BLACK); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2); gp.setMargins(0,10,0,10); root.addView(gps,gp); gps.setOnClickListener(v->getGPS());
        coordinates=label("Latitud: "+lat+"\nLongitud: "+lon,17); coordinates.setPadding(12,16,12,16); coordinates.setBackground(bg(0xFFE5EBD7)); root.addView(coordinates);
        pest=new EditText(this); pest.setText("Gusano cogollero"); pest.setTextSize(18); pest.setSingleLine(true); pest.setPadding(14,5,14,5); pest.setBackground(bg(Color.WHITE));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,58); ep.setMargins(0,14,0,14); root.addView(pest,ep);
        Button next=btn("CONTINUAR",green,Color.WHITE); root.addView(next); next.setOnClickListener(v->{ Intent i=new Intent(this,SummaryActivity.class); i.putExtra("lat",lat); i.putExtra("lon",lon); i.putExtra("pest",pest.getText().toString()); i.putExtra("photo",photo64); startActivity(i); });
    }
    void getGPS() {
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION); return; }
        try {
            LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
            Location l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(l==null) l=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(l!=null) { lat=String.format(java.util.Locale.US,"%.6f",l.getLatitude()); lon=String.format(java.util.Locale.US,"%.6f",l.getLongitude()); }
            coordinates.setText("Latitud: "+lat+"\nLongitud: "+lon);
            Toast.makeText(this,l==null?"Sin señal GPS; se muestran coordenadas de ejemplo":"Ubicación obtenida",Toast.LENGTH_SHORT).show();
        } catch(Exception e) { Toast.makeText(this,"No se pudo obtener la ubicación",Toast.LENGTH_SHORT).show(); }
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g) { super.onRequestPermissionsResult(r,p,g); if(r==LOCATION && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) getGPS(); }
    @Override protected void onActivityResult(int r,int c,Intent d) { super.onActivityResult(r,c,d); if(r==CAMERA && c==RESULT_OK && d!=null && d.getExtras()!=null) { Bitmap bm=(Bitmap)d.getExtras().get("data"); if(bm!=null) { photo.setImageBitmap(bm); ByteArrayOutputStream out=new ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.JPEG,65,out); photo64=Base64.encodeToString(out.toByteArray(),Base64.DEFAULT); } } }
}